int main() {
    int x = 3;
    if (x > 3) {
        x = x + 1;
    } else {
        x = x - 1;
    }
    return x;
}
