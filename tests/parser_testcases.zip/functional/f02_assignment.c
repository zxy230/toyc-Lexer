int main() {
    int x = 10;
    x = x + 5;
    return x;
}
