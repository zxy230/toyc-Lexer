int add(int a, int b) {
    return a + b;
}

int main() {
    int x = add(111, 42);
    return x;
}
