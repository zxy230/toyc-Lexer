int main() {
    return 32;
}
