int main() {
    int x = 5;
    if (x > 5) {
        return 42;
    }
    return 87
}
