int abs(int x) {
    if (x < 0 {
        return -x;
    } else {
        return x;
    }
}

int compute(int a, int b, int c, int d, int e, int f, int g, int h) {
    return a + b * c - d / (abs(e) + 1) + f % (abs(g) + 1) * h;
}

int main() {
    int v1 = ;
    int v2 = 202;
    int v3 = 303;
    int v4 = 404;
    int v5 = 505;
    int v6 = 606;
    int v7 = 707;
    int v8 = 808;
    int v9 = 909;
    int v10 = 123;
    int v11 = 234;
    int v12 = 345;
    int v13 = 456;
    int v14 = 567;
    int v15 = 678;
    int v16 = 789;
    int v17 = 890;
    int v18 = 901;
    int v19 = 12;
    int v20 = 23;
    int v21 = 34;
    int v22 = 45;
    int v23 = 56;
    int v24 = 67;
    int v25 = 78;
    int v26 = 89;
    int v27 = 90;
    int v28 = 21;
    int v29 = 32;
    int v30 = 43;
    int v31 = 54;
    int v32 = 65;

    int sum1 = v1 + v2 - v3 + v4 - v5 + v6 - v7 + v8;
    int sum2 = v9 + v10 - v11 + v12 - v13 + v14 - v15 + v16;
    int sum3 = v17 + v18 - v19 + v20 - v21 + v22 - v23 + v24;
    int sum4 = v25 + v26 - v27 + v28 - v29 + v30 - v31 + v32;

    int result1 = sum1 + sum2 - sum3 + sum4;

    {
    int u1 = v1 + 1;
    int u2 = v2 + 2;
    int u3 = v3 + 3;
    int u4 = v4 + 4;
    int u5 = v5 + 5;
    int u6 = v6 + 6;
    int u7 = v7 + 7;
    int u8 = v8 + 8;
    int u9 = v9 + 9;
    int u10 = v10 + 10;
    int u11 = v11 + 11;
    int u12 = v12 + 12;
    int u13 = v13 + 13;
    int u14 = v14 + 14;
    int u15 = v15 + 15;
    int u16 = v16 + 16;
    int u17 = v17 + 17;
    int u18 = v18 + 18;
    int u19 = v19 + 19;
    int u20 = v20 + 20;
    int u21 = v21 + 21;
    int u22 = v22 + 22;
    int u23 = v23 + 23;
    int u24 = v24 + 24;
    int u25 = v25 + 25;
    int u26 = v26 + 26;
    int u27 = v27 + 27;
    int u28 = v28 + 28;
    int u29 = v29 + 29;
    int u30 = v30 + 30;
    int u31 = v31 + 31;
    int u32 = v32 + 32;

    int sum5 = u1 + u2 - u3 + u4 - u5 + u6 - u7 + u8;
    int sum6 = u9 + u10 - u11 + u12 - u13 + u14 - u15 + u16;
    int sum7 = u17 + u18 - u19 + u20 - u21 + u22 - u23 + u24;
    int sum8 = u25 + u26 - u27 + u28 - u29 + u30 - u31 + u32;

    int result2 = sum5 + sum6 - sum7 + sum8;

        {
            int w1 = u1 + v1;
            int w2 = u2 - v2;
            int w3 = u3 + v3;
            int w4 = u4 - v4;
            int w5 = u5 + v5;
            int w6 = u6 - v6;
            int w7 = u7 + v7;
            int w8 = u8 - v8;
            int w9 = u9 + v9;
            int w10 = u10 - v10;
            int w11 = u11 + v11;
            int w12 = u12 - v12;
            int w13 = u13 + v13;
            int w14 = u14 - v14;
            int w15 = u15 + v15;
            int w16 = u16 - v16;
            int w17 = u17 + v17;
            int w18 = u18 - v18;
            int w19 = u19 + v19;
            int w20 = u20 - v20;
            int w21 = u21 + v21;
            int w22 = u22 - v22;
            int w23 = u23 + v23;
            int w24 = u24 - v24;
            int w25 = u25 + v25;
            int w26 = u26 - v26;
            int w27 = u27 + v27;
            int w28 = u28 - v28;
            int w29 = u29 + v29;
            int w30 = u30 - v30;
            int w31 = u31 + v31;
            int w32 = u32 - v32;

            int sum9 = w1 + w2 - w3 + w4 - w5 + w6 - w7 + w8;
            int sum10 = w9 + w10 - w11 + w12 - w13 + w14 - w15 + w16;
            int sum11 = w17 + w18 - w19 + w20 - w21 + w22 - w23 + w24;
            int sum12 = w25 + w26 - w27 + w28 - w29 + w30 - w31 + w32;

            int result3 = sum9 + sum10 - sum11 + sum12;

            {
                int x1 = w1 - 1;
                int x2 = w2 - 2;
                int x3 = w3 - 3;
                int x4 = w4 - 4;
                int x5 = w5 - 5;
                int x6 = w6 - 6;
                int x7 = w7 - 7;
                int x8 = w8 - 8;
                int x9 = w9 - 9;
                int x10 = w10 - 10;
                int x11 = w11 - 11;
                int x12 = w12 - 12;
                int x13 = w13 - 13;
                int x14 = w14 - 14;
                int x15 = w15 - 15;
                int x16 = w16 - 16;
                int x17 = w17 - 17;
                int x18 = w18 - 18;
                int x19 = w19 - 19;
                int x20 = w20 - 20;
                int x21 = w21 - 21;
                int x22 = w22 - 22;
                int x23 = w23 - 23;
                int x24 = w24 - 24;
                int x25 = w25 - 25;
                int x26 = w26 - 26;
                int x27 = w27 - 27;
                int x28 = w28 - 28;
                int x29 = w29 - 29;
                int x30 = w30 - 30;
                int x31 = w31 - 31;
                int x32 = w32 - 32;

                int sum13 = x1 + x2 - x3 + x4 - x5 + x6 - x7 + x8;
                int sum14 = x9 + x10 - x11 + x12 - x13 + x14 - x15 + x16;
                int sum15 = x17 + x18 - x19 + x20 - x21 + x22 - x23 + x24;
                int sum16 = x25 + x26 - x27 + x28 - x29 + x30 - x31 + x32;

                int result4 = sum13 + sum14 - sum15 + sum16;

                int final_result = compute(result1, result2, result3, result4,
                                           sum1, sum5, sum9, sum13);

                return final_result;
            }
        }
    }
}
