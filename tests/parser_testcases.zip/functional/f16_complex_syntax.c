int/*Multi-line comment with /*
   * and some tricky symbols: (){};
   // Comment inside multi-line
   */factorial(int/*comment*/n
    // Parameter declaration with comment
/*Another comment*/
   ){
      int/*comment*/result=1/*Initial value
      * with multi-line comment*/;
      if/*comment*/(n<=/*comment*/0)/*comment*/{ return/*comment*/1/*Base case
         * for factorial*/;
      }else/*comment*/{
         while/*nested*/(n/*comment*/>/*gt*/1/*comment*/){result=result*/*multiply*/n;n=n-/*decrement*/1/*not using ++ as specified*/;}return/*
         /*
         //
         */ result;
      }/*
   }*/}/*end of factorial*/int/*
   *
*/main(// int unused_param,/* /
/*int another_param*/
   ){
int x=-3/*-10*/;int y=-/*4*/2;int z=0;
      if(x>y && /*logical and*/(x-y)/*subtraction*/>1){
    z = factorial /*function call*/ (x) //*division*/factorial(y);
;}else
if (x < y || /*logical or*/ x == y) {z=factorial(-(x/*addition*/ +y));
      }else{z = factorial(x * /*multiplication*/ y);
}
      while/*(1+1==2)*/(z>100
){if(z%/*%*/2==1){z=z/2
;}else{z=z-1
    ;}}
      return/*-*/
      z/***
*
division operator*//factorial(3)/*}
    * //
    */;
   /*end of function*/
