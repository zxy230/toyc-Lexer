int main) {
    int x = 111 + 42 * 37;
    return x; // EVAL("t1 + t2 * t3")
}
